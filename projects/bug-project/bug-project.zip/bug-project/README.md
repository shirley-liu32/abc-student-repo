# Alert Extension
## Mini Project 4 - Shirley Liu


This Alert Extension will constantly give you random alerts for no reason. User will feel lost about how to close it and constantly annoyed by the sometimes hopeful messages. You got someone you're not quite fond of, why don't you download this extension on their computer just to mess with them. They'll be disturbed and have trouble closing all the popups. Have fun and stay safe kids!

![Alert Extension](example.png)