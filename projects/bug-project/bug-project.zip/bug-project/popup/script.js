while (true){
    let r =confirm("do you like dogs");
    if (r==true)
    {
    alert("yay");
    }
    else
    {
    alert("you suck");
    }
    alert("haha try me");
    alert("[dis is a funny message]");
    alert("you still see me");
    let message  =confirm("would you like to close the alerts");
    if (message==true)
    {
    alert("fine");
    }
    else
    {
    alert("oh you don't?");    
    }
    alert("you can close me now if you click the extension again");
    alert("you thought you closed it this time"); 
}
